from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import *
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout,update_session_auth_hash
#update_session_auth_hash this is for redirect to the home page after chage the password
from django.contrib.auth.decorators import login_required
from django.core.mail import send_mail
# Create your views here.
@login_required(login_url="login")
def index(request):
    if request.method=='POST':
        firstname=request.POST.get('firstname')
        middlename=request.POST.get('middlename')
        lastname=request.POST.get('lastname')
        fname=request.POST.get('fname')
        mname=request.POST.get('mname')
        dateofbirth=request.POST.get('dateofbirth')
        mobile1=request.POST.get('mobile1')
        mobile2=request.POST.get('mobile1')
        amobile=request.POST.get('amobile')
        email1=request.POST.get('email1')
        email2=request.POST.get('email2')
        address1=request.POST.get('address1')
        address2=request.POST.get('address2')
        city=request.POST.get('city')
        state=request.POST.get('state')
        zipcode=request.POST.get('zipcode')
        country=request.POST.get('country')
        nationality=request.POST.get('nationality')
        photo=request.FILES['photo']
        signature=request.FILES['signature']
        thumbnail=request.FILES['thumbnail']
        data=Save_data(firstname=firstname,middlename=middlename,lastname=lastname,
                            fname=fname,mname=mname,dateofbirth=dateofbirth,
                            mobile1=mobile1,mobile2=mobile2,amobile=amobile,
                            email1=email1,email2=email2,address1=address1,
                            address2=address2,city=city,state=state,
                            zipcode=zipcode,country=country,nationality=nationality,
                            photo=photo,signature=signature,thumbnail=thumbnail)
        data.save()
        messages.success(request,"You have been submitted your data!!!")
        return redirect('/')
    return render(request, 'index.html')

def signup(request):
    if request.method=="POST":
        username=request.POST.get('username')
        email=request.POST.get('email')
        email=email.strip()
        phone=request.POST.get('phone')
        password=request.POST.get('password')
        myuser = User.objects.create_user(username,email,password)
        myuser.phone=phone
        myuser.save()
        
        subject='About Registration'
        message= f'Hi {username}, You have been registered successfully on Submit From.'
        email_from='pradip8298@gmail.com'
        rec_list=[email,]

        send_mail(subject,message,email_from,rec_list)
        
        return redirect("login")
    else:
        return redirect("signup")
    

def LoginPage(request):
    if request.method=="POST":
        username=request.POST.get('username')
        pass1=request.POST.get('pass1')
        user = authenticate(request,username=username, password=pass1)
        if user is not None:
            login(request,user)
            return redirect("/")
            
        else:
            return HttpResponse("Invalid Username and Password!!")
    return render(request,  'login.html')
    
def LogoutPage(request):
    logout(request)
    return redirect('login')

def ForgotPage(request):
    return render(request,'forgot.html')

def change_password(request):
    return render(request,'change_password.html')

def chngpass(request):
    if request.method=="POST":
        newpass=request.POST.get('chngpass')
        u=User.objects.get(username=request.user.username)
        u.set_password(newpass)
        u.save()
        update_session_auth_hash(request,u)
        messages.success(request,"You password have changes Successfully!1")
        return redirect('/')
    return render(request,'chngpass.html')
