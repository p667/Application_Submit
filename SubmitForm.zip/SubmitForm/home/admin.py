from django.contrib import admin
from home.models import Save_data
# Register your models here.
admin.site.register(Save_data)
