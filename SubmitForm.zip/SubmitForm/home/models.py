from django.db import models

# Create your models here.
class Save_data(models.Model):
    firstname=models.CharField(max_length=100,blank=True,null=True)
    middlename=models.CharField(max_length=100,blank=True,null=True)
    lastname=models.CharField(max_length=50, blank=True,null=True)
    fname=models.CharField(max_length=100 , blank=True, null=True)
    mname=models.CharField(max_length=100, blank=True , null=True)
    dateofbirth = models.DateField(blank=True, null=True)
    mobile1=models.CharField(max_length=10, blank=True , null=True)
    mobile2=models.CharField(max_length=10,blank=True, null=True)
    amobile=models.CharField(max_length=10,blank=True,null=True)
    email1=models.CharField(max_length=50,blank=True,null=True)
    email2=models.CharField(max_length=50,blank=True,null=True)
    address1=models.CharField(max_length=200,blank=True,null=True)
    address2=models.CharField(max_length=200,blank=True,null=True)
    city=models.CharField(max_length=50,blank=True,null=True)
    state=models.CharField(max_length=50,blank=True,null=True)
    zipcode=models.CharField(max_length=10,blank=True,null=True)
    country=models.CharField(max_length=50,default=None,blank=True,null=True)
    nationality=models.CharField(max_length=50,default=None,blank=True,null=True)

    photo=models.ImageField(upload_to="images")
    signature=models.ImageField(upload_to="images")
    thumbnail=models.ImageField(upload_to="images")

    def __str__(self):
        return self.firstname + " " +self.lastname